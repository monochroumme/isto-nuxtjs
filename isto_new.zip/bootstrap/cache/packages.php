<?php return array (
  'ebess/advanced-nova-media-library' => 
  array (
    'providers' => 
    array (
      0 => 'Ebess\\AdvancedNovaMediaLibrary\\AdvancedNovaMediaLibraryServiceProvider',
    ),
  ),
  'energon7/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'hnassr/nova-key-value' => 
  array (
    'providers' => 
    array (
      0 => 'Hnassr\\NovaKeyValue\\FieldServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'ofcold/nova-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Ofcold\\NovaSortable\\ToolServiceProvider',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'whitecube/nova-flexible-content' => 
  array (
    'providers' => 
    array (
      0 => 'Whitecube\\NovaFlexibleContent\\FieldServiceProvider',
    ),
  ),
);